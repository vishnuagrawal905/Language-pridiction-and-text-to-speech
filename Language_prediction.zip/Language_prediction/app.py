import streamlit as st
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from gtts import gTTS
import pygame
import time
import os

# Title
st.title("🌍 Language Detection & Text-to-Speech")
st.markdown("Enter a sentence, get the predicted language, and hear it spoken aloud.")

# Load and train model once
@st.cache_resource
def load_model():
    data = pd.read_csv("Language.csv")
    x = np.array(data["Text"])
    y = np.array(data["language"])
    cv = CountVectorizer()
    X = cv.fit_transform(x)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
    model = MultinomialNB()
    model.fit(X_train, y_train)
    return model, cv

model, cv = load_model()

# Text input
user_input = st.text_area("Enter text here:")

if st.button("Predict & Speak"):
    if not user_input.strip():
        st.warning("Please enter some text.")
    else:
        X_input = cv.transform([user_input]).toarray()
        prediction = model.predict(X_input)[0]
        st.success(f"Predicted Language: {prediction}")

        # Map to language code
        lang_map = {'English': 'en', 'Hindi': 'hi', 'Urdu': 'ur', 'Tamil': 'ta'}
        lang_code = lang_map.get(prediction, 'en')

        # TTS
        audio_file = "output_audio.mp3"
        if os.path.exists(audio_file):
            pygame.mixer.music.stop()
            pygame.mixer.quit()
            time.sleep(1)
            os.remove(audio_file)

        tts = gTTS(text=user_input, lang=lang_code)
        tts.save(audio_file)

        pygame.mixer.init()
        pygame.mixer.music.load(audio_file)
        pygame.mixer.music.play()

        st.audio(audio_file, format="audio/mp3")

        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)

        pygame.mixer.music.stop()
        pygame.mixer.quit()
        os.remove(audio_file)
